function sendOTP(){
    const email = document.getElementById('email');
    const otpverify = document.getElementsByClassName('otpverify')[0];

  

    // Generating random number as OTP;

    let otp_val = Math.floor(Math.random()*10000);

    let emailbody = `
        <h1>Your Verification OTP code</h1> <br>
        <h2>Your OTP is </h2>${otp_val}
    `;

    Email.send({
        SecureToken : "1e335b15-5b75-4619-bc8d-accbfe6b6230", // Encrypted Email details
        To : email.value,
        From : "ranthatigenisansa2021@gmail.com",  // Sender's Email (Better to have a group email)
        Subject : "Verify OTP code",
        Body : emailbody
    }).then(
        //if success it returns "OK";
      message => {
        if(message === "OK"){
            alert("OTP sent to your email "+email.value);

            // now making otp input visible
            otpverify.style.display = "block";
            const otp_inp = document.getElementById('otp_inp');
            const otp_btn = document.getElementById('otp-btn');

            otp_btn.addEventListener('click',()=>{
                // now check whether sent email is valid
                if(otp_inp.value == otp_val){
                    alert("Email address verified...");   // navigation to the other web page
                }
                else{
                    alert("Invalid OTP");
                }
            })
        }
      }
    );

}