import React from 'react'

export default function Projects() {
  return (
    <div>Projects</div>
  )
}
